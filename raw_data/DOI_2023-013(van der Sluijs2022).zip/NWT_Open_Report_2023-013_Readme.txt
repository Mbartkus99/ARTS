- Publication citation

van der Sluijs, J., and Kokelj, S.V., 2023. A detailed inventory of retrogressive thaw slump affected slopes using high spatial resolution digital elevation models and imagery, Peel Plateau and Anderson Plain � Tuktoyaktuk Coastlands, Northwest Territories; Northwest Territories Geological Survey, NWT Open Report 2023-013, 9 pages and digital data. https://doi.org/10.46887/2023-013


- Introduction/Purpose

Retrogressive thaw slumping (RTS) is a dominant modifier of ice-rich permafrost slopes, requiring investigations into the distribution and intensification of these disturbances. Optical remote sensing products 
are typically used for RTS detection and delineation; however, high-resolution elevation models provide new opportunities for detection and insights into geomorphic change. This work summarizes efforts to characterize 
a diverse range of RTS disturbance morphologies and activity levels in two areas in the Beaufort Delta (Canada) over three observation periods (2004, 2011, and 2016). A set of delineation principles were devised to provide 
temporally consistent information on thaw slump affected slopes and attributes. These principles, along with the simultaneous use of both optical and elevation remote sensing products, has culminated in the concept of 
a Multisource Slump Inventory (MSI). The MSI�s purpose is to track temporal and spatial trends in these multi-year, chronic mass-wasting features. Rather than only tracking active RTS, the MSI is particularly adapted 
to inactive and old disturbances that may reactivate in the future, posing a geohazard that is difficult to detect without a MSI approach. Delineations were conducted in the Peel Plateau and Anderson Plain-Tuktoyaktuk Coastlands (APTC) 
physiographic regions, using high-resolution hillshaded digital elevation models (DEM) and ortho-mosaics for 2004, 2011, and 2016. 2004 data is based on Mackenzie Valley Air Photo project, 2011 data is based on a 
Light Detection and Ranging and ortho-mosaic project for the Dempster and Inuvik-to-Tuktoyaktuk Highway corridors. Circa 2016 data is based on ArcticDEM (Porter et al., 2018) and ESRI World Imagery baselayer.


- Projection information

NAD83 (Canadian Spatial Reference System) UTM Zone 8N.


- List and brief description of folders and contents

Three files are provided: MSI_2022_10.shp (containing slump delineations for the two study areas and three observation periods), Mapping_Extents.shp (spatial extent of study areas), 
ArcticDEM_Mosaic_Nodata.shp (areas in ArcticDEM product without any data, preventing delineations in these areas)


- Software requirements and special instructions

Shapefiles are standardized GIS file formats, requiring commercial or open-source GIS software for access and use. Projection is stored in.PRJ files.


- List of references

Please refer to the reference list in the associated NWT Open Report.


- Acknowledgements

The work was supported by the Department of Environment and Natural Resources Climate Change and Northwest Territories Cumulative Impact Monitoring Program of the GNWT (grant nos. 164 and 186, Steven V. Kokelj), 
the Natural Science and Engineering Research Council of Canada, and the Polar Continental Shelf Program, Natural Resources Canada (projects 313-18, 316-19, 318-20, and 320-20 to Steven V. Kokelj. 
William Woodley (NWT Centre for Geomatics) processed MVAP contour lines into the 3-m DEM).


- Author(s) contact information

Jurjen van der Sluijs, Northwest Territories Centre for Geomatics, Government of the Northwest Territories, Yellowknife, NT X1A 2L9 (jurjen_vandersluijs@gov.nt.ca)
Steven V. Kokelj, Northwest Territories Geological Survey, Government of the Northwest Territories, Yellowknife, NT X1A 2L9 (steve_kokelj@gov.nt.ca)


- Disclaimer

Please contact the Northwest Territories Centre for Geomatics to obtain access to GNWT administered data (2004, 2011). 
Circa 2016 delineations may not align with current ESRI World Imagery baselayer due to occasional updating of this base layer. Use as-is.
